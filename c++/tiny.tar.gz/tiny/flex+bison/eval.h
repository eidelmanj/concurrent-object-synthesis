#ifndef EVAL_H
#define EVAL_H

#include "tree.h"

int evalEXP(EXP *e);

#endif /* !EVAL_H */
